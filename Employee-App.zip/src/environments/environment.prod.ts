export const environment = {
  production: true,
  apiUrl: 'http://10.8.66.114:8585'
};
